import type { Patient } from '../types';

export const morePatients: Record<string, Patient> = {
  "NHS-24680": {
    id: "NHS-24680",
    demographics: {
      name: "Maria Garcia",
      dob: "1998-07-22",
      nhs_number: "246 801 3579"
    },
    admission_reason: "Acute appendicitis.",
    clinical_notes: "Presented to A&E with severe right lower quadrant pain, nausea, and fever. CT scan confirmed appendicitis. Underwent emergency laparoscopic appendectomy on 2025-07-03. Procedure was uncomplicated. Post-operatively, managed with IV fluids and analgesia. Mobilizing well and tolerating oral diet. Surgical wounds are clean, dry, and intact. Discharged with oral antibiotics.",
    lab_results: [
      {test: "White Blood Cell Count", value: "18.5 x 10^9/L", status: "Elevated on admission, normalized post-op"},
      {test: "C-Reactive Protein", value: "150 mg/L", status: "Elevated on admission, trending down"}
    ],
    medication_changes: [
      {medication: "Co-amoxiclav", dose: "625mg", frequency: "TDS", status: "Continue for 7 days"},
      {medication: "Ibuprofen", dose: "400mg", frequency: "PRN", status: "As needed for pain, max 3 times a day"},
      {medication: "Oxycodone", dose: "5mg", frequency: "PRN", status: "For severe pain, dispensed 10 tablets"}
    ]
  },
  "NHS-13579": {
    id: "NHS-13579",
    demographics: {
      name: "David Chen",
      dob: "1955-11-10",
      nhs_number: "135 792 4680"
    },
    admission_reason: "Admitted with central crushing chest pain, diagnosed with NSTEMI (Non-ST-Elevation Myocardial Infarction).",
    clinical_notes: "Admitted via ambulance on 2025-06-30. ECG showed T-wave inversion. Troponin levels were elevated. Commenced on dual antiplatelet therapy and therapeutic LMWH. Coronary angiogram on 2025-07-01 revealed 80% stenosis in Left Anterior Descending artery, which was stented. Remained hemodynamically stable post-procedure. Echocardiogram showed mild LV impairment (EF 45%). Referred to cardiac rehabilitation. Discharged to be followed up in cardiology clinic.",
    lab_results: [
      {test: "Troponin-T", value: "850 ng/L", status: "Peaked and now trending down"},
      {test: "Cholesterol", value: "6.2 mmol/L", status: "Elevated"}
    ],
    medication_changes: [
      {medication: "Aspirin", dose: "75mg", frequency: "OD", status: "Lifelong"},
      {medication: "Clopidogrel", dose: "75mg", frequency: "OD", status: "Continue for 12 months"},
      {medication: "Atorvastatin", dose: "80mg", frequency: "ON", status: "Lifelong"},
      {medication: "Bisoprolol", dose: "2.5mg", frequency: "OD", status: "Lifelong"},
      {medication: "Ramipril", dose: "2.5mg", frequency: "OD", status: "Lifelong"},
      {medication: "GTN Spray", dose: "1-2 sprays", frequency: "PRN", status: "As needed for chest pain"}
    ]
  }
};
