import type { Patient } from '../types';
import { morePatients } from './morePatientData';

const initialPatients: Record<string, Patient> = {
  "NHS-12345": {
    id: "NHS-12345",
    demographics: {
      name: "John Smith",
      dob: "1965-03-15",
      nhs_number: "123 456 7890"
    },
    admission_reason: "Patient presented with community-acquired pneumonia.",
    clinical_notes: "Admitted on 2025-06-28. Treated with IV antibiotics (Amoxicillin). Responded well to treatment. Chest X-ray on 2025-07-02 showed significant improvement. Patient is now afebrile and clinically stable. Ready for discharge.",
    lab_results: [
      {test: "C-Reactive Protein", value: "15 mg/L", status: "Decreased"},
      {test: "White Blood Cell Count", value: "9.5 x 10^9/L", status: "Normal"}
    ],
    medication_changes: [
      {medication: "Amoxicillin", dose: "500mg", frequency: "TDS", status: "Continue for 5 more days"},
      {medication: "Paracetamol", dose: "1g", frequency: "PRN", status: "As needed for pain"}
    ]
  },
  "NHS-67890": {
    id: "NHS-67890",
    demographics: {
      name: "Jane Doe",
      dob: "1982-11-20",
      nhs_number: "098 765 4321"
    },
    admission_reason: "Exacerbation of Chronic Obstructive Pulmonary Disease (COPD).",
    clinical_notes: "Admitted on 2025-07-01 with shortness of breath. Treated with nebulizers, steroids, and oxygen therapy. Clinically improved and weaned off oxygen. Stable for discharge with follow-up from respiratory nurse.",
    lab_results: [
      {test: "Arterial Blood Gas", value: "pH 7.42, PaO2 8.5 kPa", status: "Stable"}
    ],
    medication_changes: [
      {medication: "Prednisolone", dose: "30mg", frequency: "OD", status: "Tapering dose over 7 days"},
      {medication: "Salbutamol Inhaler", dose: "2 puffs", frequency: "QDS", status: "Continue"}
    ]
  }
};

export const PATIENT_DATABASE: Record<string, Patient> = {
  ...initialPatients,
  ...morePatients
};


export const getPatientData = (patientId: string): Patient | null => {
    console.log(`--- TOOL: Fetching data for patient ${patientId} ---`);
    return PATIENT_DATABASE[patientId] || null;
}
