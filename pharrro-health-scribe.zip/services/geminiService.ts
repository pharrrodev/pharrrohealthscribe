
import { GoogleGenAI } from "@google/genai";
import type { Patient } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const synthesisSystemInstruction = `You are a clinical assistant. Your task is to synthesize raw patient data into a concise, narrative clinical summary. Focus on the key events, treatments, and outcomes. Do not add any information not present in the provided data. The output should be a single paragraph of prose.`;

export const synthesizeClinicalData = async (patientData: Patient): Promise<string> => {
    const prompt = `
    Please synthesize the following patient data into a single, coherent paragraph for a clinical summary.

    Patient Demographics:
    - Name: ${patientData.demographics.name}
    - DOB: ${patientData.demographics.dob}

    Admission Reason: ${patientData.admission_reason}

    Clinical Notes: ${patientData.clinical_notes}

    Lab Results:
    ${patientData.lab_results.map(r => `- ${r.test}: ${r.value} (${r.status})`).join('\n')}

    Medication Changes on Discharge:
    ${patientData.medication_changes.map(m => `- ${m.medication} ${m.dose} ${m.frequency}: ${m.status}`).join('\n')}
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: prompt,
            config: {
                systemInstruction: synthesisSystemInstruction,
                temperature: 0.5,
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error synthesizing clinical data:", error);
        throw new Error("Failed to synthesize clinical data with Gemini API.");
    }
};

const draftSystemInstruction = `You are an expert medical scribe. Your task is to generate a structured, patient-friendly discharge summary based on the provided clinical synthesis. The summary must be well-organized with clear headings. Use markdown for formatting. The sections should be: "## Reason for Admission", "## Hospital Course", "## Discharge Medications", and "## Follow-up Plan". If the user provides an edit request, incorporate it into the new draft.`;

export const generateDraftSummary = async (synthesizedNotes: string, patientData: Patient, editRequest?: string): Promise<string> => {
    const prompt = `
    Clinical Synthesis:
    ---
    ${synthesizedNotes}
    ---
    
    Discharge Medications from patient record:
    ${patientData.medication_changes.map(m => `- ${m.medication} ${m.dose} ${m.frequency}: ${m.status}`).join('\n')}

    Task:
    Generate a structured discharge summary with the markdown sections: "## Reason for Admission", "## Hospital Course", "## Discharge Medications", and "## Follow-up Plan". The 'Follow-up Plan' should be inferred from the context (e.g., continuing medications, respiratory nurse follow-up).
    
    ${editRequest ? `IMPORTANT: Please apply the following edits to the summary: "${editRequest}"` : ''}
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: prompt,
            config: {
                systemInstruction: draftSystemInstruction,
                temperature: 0.7,
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error generating draft summary:", error);
        throw new Error("Failed to generate draft summary with Gemini API.");
    }
};