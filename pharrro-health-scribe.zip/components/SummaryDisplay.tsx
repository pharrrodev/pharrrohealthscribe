import React, { useState, useEffect } from 'react';
import { marked } from 'marked';
import DOMPurify from 'dompurify';
import { AgentStatus } from '../types';
import { PencilSquareIcon } from './icons/PencilSquareIcon';

interface SummaryDisplayProps {
  status: AgentStatus;
  draftSummary: string;
  finalSummary: string;
  onApprove: () => void;
  onRequestEdits: (editRequest: string) => void;
}

const RenderMarkdown: React.FC<{ content: string }> = ({ content }) => {
    // Note: It's crucial to sanitize HTML that comes from external sources (like an LLM)
    // to prevent XSS attacks if the content were ever to include executable scripts.
    const sanitizedHtml = DOMPurify.sanitize(marked.parse(content) as string);
    return (
        <div 
            className="prose prose-slate max-w-none" 
            dangerouslySetInnerHTML={{ __html: sanitizedHtml }}
        />
    );
};

const SkeletonLoader: React.FC = () => (
    <div className="space-y-4 animate-pulse">
      <div className="h-4 bg-slate-200 rounded w-1/3"></div>
      <div className="h-3 bg-slate-200 rounded w-full"></div>
      <div className="h-3 bg-slate-200 rounded w-5/6"></div>
      <div className="h-4 bg-slate-200 rounded w-1/2 mt-6"></div>
      <div className="h-3 bg-slate-200 rounded w-full"></div>
      <div className="h-3 bg-slate-200 rounded w-full"></div>
      <div className="h-3 bg-slate-200 rounded w-3/4"></div>
    </div>
);


const SummaryDisplay: React.FC<SummaryDisplayProps> = ({ status, draftSummary, finalSummary, onApprove, onRequestEdits }) => {
  const [showEditModal, setShowEditModal] = useState(false);
  const [editRequestText, setEditRequestText] = useState('');

  useEffect(() => {
    if (!showEditModal) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setShowEditModal(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [showEditModal]);

  const handleRequestEdits = () => {
    if(editRequestText.trim()){
      onRequestEdits(editRequestText);
      setShowEditModal(false);
      setEditRequestText('');
    }
  };

  const content = status === 'finished' ? finalSummary : draftSummary;
  const showSkeleton = (status === 'running' || status === 'editing') && !content;

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-slate-200 h-full flex flex-col">
      <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center">
        <PencilSquareIcon className="w-6 h-6 mr-2 text-blue-600" />
        3. Discharge Summary
      </h2>
      <div className="flex-grow bg-slate-50 rounded-lg p-4 overflow-y-auto text-sm text-slate-700 min-h-[300px]">
        {showSkeleton && <SkeletonLoader />}
        {status === 'idle' && !showSkeleton && <p className="text-slate-500">Summary will be generated here...</p>}
        {content && <RenderMarkdown content={content} />}
      </div>
      {status === 'awaiting_approval' && (
        <div className="mt-4 pt-4 border-t border-slate-200 flex flex-col sm:flex-row gap-4">
          <button
            onClick={onApprove}
            className="flex-1 px-4 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-75 transition duration-150 ease-in-out"
          >
            Approve
          </button>
          <button
            onClick={() => setShowEditModal(true)}
            className="flex-1 px-4 py-2 bg-yellow-500 text-white font-semibold rounded-lg shadow-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-opacity-75 transition duration-150 ease-in-out"
          >
            Request Edits
          </button>
        </div>
      )}
      {showEditModal && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          onClick={() => setShowEditModal(false)}
        >
          <div 
            className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md"
            onClick={(e) => e.stopPropagation()} // Prevent modal from closing when clicking inside it
          >
            <h3 className="text-lg font-bold mb-4">Request Edits</h3>
            <p className="text-sm text-slate-600 mb-4">Please provide instructions for the changes you'd like to see in the summary.</p>
            <textarea
              value={editRequestText}
              onChange={(e) => setEditRequestText(e.target.value)}
              className="w-full h-32 p-2 border border-slate-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., 'Make the tone more reassuring for the patient.'"
              autoFocus
            />
            <div className="mt-4 flex justify-end gap-3">
              <button onClick={() => setShowEditModal(false)} className="px-4 py-2 bg-slate-200 text-slate-800 rounded-md hover:bg-slate-300">Cancel</button>
              <button onClick={handleRequestEdits} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Submit Edits</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SummaryDisplay;