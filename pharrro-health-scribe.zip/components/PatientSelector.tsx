import React from 'react';
import { PATIENT_DATABASE } from '../data/patientData';
import type { AgentStatus } from '../types';

interface PatientSelectorProps {
  selectedPatientId: string | null;
  status: AgentStatus;
  onPatientSelect: (patientId: string) => void;
  onGenerate: () => void;
  onReset: () => void;
}

const PatientSelector: React.FC<PatientSelectorProps> = ({ selectedPatientId, status, onPatientSelect, onGenerate, onReset }) => {
  const isProcessing = status === 'running' || status === 'editing' || status === 'awaiting_approval';
  const isFinished = status === 'finished' || status === 'error';

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-slate-200">
      <h2 className="text-xl font-bold text-slate-800 mb-4">1. Select Patient & Generate</h2>
      <div className="flex flex-col sm:flex-row gap-4">
        <select
          value={selectedPatientId || ''}
          onChange={(e) => onPatientSelect(e.target.value)}
          disabled={isProcessing}
          className="flex-grow bg-slate-50 border border-slate-300 text-slate-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 transition duration-150 ease-in-out disabled:bg-slate-200 disabled:cursor-not-allowed"
        >
          <option value="" disabled>Choose a patient...</option>
          {Object.keys(PATIENT_DATABASE).map(patientId => (
            <option key={patientId} value={patientId}>
              {PATIENT_DATABASE[patientId].demographics.name} ({patientId})
            </option>
          ))}
        </select>
        
        {isFinished ? (
            <button
              onClick={onReset}
              className="px-6 py-2.5 bg-slate-600 text-white font-semibold rounded-lg shadow-md hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-opacity-75 transition duration-150 ease-in-out"
            >
              Start Over
            </button>
        ) : (
            <button
              onClick={onGenerate}
              disabled={!selectedPatientId || isProcessing}
              className="px-6 py-2.5 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75 disabled:bg-slate-400 disabled:cursor-not-allowed transition duration-150 ease-in-out"
            >
              {isProcessing ? 'Processing...' : 'Generate Summary'}
            </button>
        )}
      </div>
    </div>
  );
};

export default PatientSelector;