import React from 'react';
import { AuditLogEntry, AuditLogStatus } from '../types';
import { CheckCircleIcon } from './icons/CheckCircleIcon';
import { ClockIcon } from './icons/ClockIcon';
import { UserCircleIcon } from './icons/UserCircleIcon';
import { XCircleIcon } from './icons/XCircleIcon';
import { DocumentTextIcon } from './icons/DocumentTextIcon';

const getStatusIcon = (status: AuditLogStatus) => {
    switch (status) {
        case 'completed':
            return <CheckCircleIcon className="w-6 h-6 text-green-500" />;
        case 'in_progress':
            return <div className="w-6 h-6 flex items-center justify-center"><div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div></div>;
        case 'error':
            return <XCircleIcon className="w-6 h-6 text-red-500" />;
        case 'human_input':
            return <UserCircleIcon className="w-6 h-6 text-yellow-500" />;
        case 'pending':
        default:
            return <ClockIcon className="w-6 h-6 text-slate-400" />;
    }
};

const getStatusColor = (status: AuditLogStatus): string => {
  switch (status) {
    case 'completed':
        return 'border-green-500';
    case 'in_progress':
        return 'border-blue-500';
    case 'error':
        return 'border-red-500';
    case 'human_input':
        return 'border-yellow-500';
    case 'pending':
    default:
        return 'border-slate-300';
  }
}

interface WorkflowTrackerProps {
  auditLog: AuditLogEntry[];
  allSteps: string[];
}

const WorkflowTracker: React.FC<WorkflowTrackerProps> = ({ auditLog, allSteps }) => {
    const isIdle = auditLog.length === 0;

    // A map for quick lookup of the latest log entry for a given step.
    // Handles cases where a step might appear multiple times (like regeneration).
    const logMap = new Map<string, AuditLogEntry>();
    auditLog.forEach(entry => {
        // Handle "Regenerate Draft" as an update to "Generate Draft Summary" for display purposes
        const stepKey = entry.step === 'Regenerate Draft' ? 'Generate Draft Summary' : entry.step;
        logMap.set(stepKey, entry);
    });

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-slate-200 h-full">
      <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center">
        <DocumentTextIcon className="w-6 h-6 mr-2 text-blue-600" />
        2. Agent Workflow & Audit Log
      </h2>
      <div className="space-y-2">
        {isIdle ? (
            <p className="text-slate-500 p-4 text-center">Workflow will begin after patient selection.</p>
        ) : (
            allSteps.map((stepName, index) => {
                const entry = logMap.get(stepName);
                const status = entry?.status ?? 'pending';
                const isPending = !entry;
                const details = entry?.details ?? 'Waiting to start...';
                const timestamp = entry?.timestamp ?? '';
                
                // Don't show "Workflow Complete" until it's actually logged
                if (stepName === 'Workflow Complete' && isPending) {
                    return null;
                }
                
                // Special handling for edit loop, show a new entry for it.
                const regenerationLog = auditLog.find(log => log.step === 'Regenerate Draft');
                if (stepName === 'Human Review' && regenerationLog) {
                     logMap.set('Regenerate Draft', regenerationLog);
                }


                return (
                    <div key={index} className="flex items-start gap-4">
                        <div className="flex flex-col items-center h-full">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center bg-slate-100 border-2 ${getStatusColor(status)} shrink-0`}>
                                {getStatusIcon(status)}
                            </div>
                            {index < allSteps.length - 1 && <div className="w-0.5 grow min-h-[4rem] bg-slate-200"></div>}
                        </div>
                        <div className={`pt-1.5 flex-grow ${isPending ? 'opacity-50' : ''}`}>
                            <p className="font-semibold text-slate-700">{stepName}</p>
                            <p className="text-sm text-slate-500">{details}</p>
                            {timestamp && <p className="text-xs text-slate-400 mt-1">{timestamp}</p>}
                        </div>
                    </div>
                );
            })
        )}
      </div>
    </div>
  );
};

export default WorkflowTracker;